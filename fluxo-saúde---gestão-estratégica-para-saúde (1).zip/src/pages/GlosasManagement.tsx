import React, { useState, useEffect } from 'react';
import { 
  AlertCircle, 
  CheckCircle2, 
  Filter, 
  RotateCcw, 
  FileText,
  TrendingDown,
  Clock,
  Ban,
  ChevronRight,
  MoreVertical
} from 'lucide-react';
import { clsx } from 'clsx';

export const GlosasManagement: React.FC = () => {
  const [productions, setProductions] = useState<any[]>([]);
  const [summary, setSummary] = useState({ total_glosado: 0, total_em_recurso: 0, total_definitivo: 0 });
  const [filters, setFilters] = useState({ clinic_id: '', insurance_id: '', professional_id: '', status: '' });
  const [clinics, setClinics] = useState<any[]>([]);
  const [insurances, setInsurances] = useState<any[]>([]);
  const [professionals, setProfessionals] = useState<any[]>([]);
  
  const [selectedProd, setSelectedProd] = useState<any | null>(null);
  const [glosaForm, setGlosaForm] = useState({ value: '', reason: '', status: 'EM_RECURSO' });

  const fetchData = async () => {
    const query = new URLSearchParams(filters).toString();
    try {
      const [prods, summ, c, i, p] = await Promise.all([
        fetch(`/api/productions/glosas-list?${query}`).then(r => r.json()),
        fetch('/api/glosas/summary').then(r => r.json()),
        fetch('/api/clinics').then(r => r.json()),
        fetch('/api/health-insurances').then(r => r.json()),
        fetch('/api/professionals').then(r => r.json())
      ]);
      
      if (Array.isArray(prods)) setProductions(prods);
      if (summ) setSummary(summ);
      if (Array.isArray(c)) setClinics(c);
      if (Array.isArray(i)) setInsurances(i);
      if (Array.isArray(p)) setProfessionals(p);
    } catch (error) {
      console.error("Erro ao buscar dados:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, [filters]);

  const handleMarkGlosa = async () => {
    if (!selectedProd) return;
    const response = await fetch(`/api/productions/${selectedProd.id}/glosa`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(glosaForm)
    });
    if (response.ok) {
      setSelectedProd(null);
      fetchData();
    }
  };

  const handleRevert = async (id: number) => {
    const response = await fetch(`/api/productions/${id}/revert-glosa`, { method: 'POST' });
    if (response.ok) fetchData();
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Gestão de Glosas</h1>
          <p className="text-slate-500 text-sm">Controle e recurso de faturamentos negados pelos convênios.</p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="h-12 w-12 rounded-2xl bg-red-50 flex items-center justify-center text-red-600">
              <Ban size={24} />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Total Glosado</div>
              <div className="text-2xl font-bold text-slate-900">R$ {(summary.total_glosado || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
            </div>
          </div>
          <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-red-500 w-[100%]"></div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="h-12 w-12 rounded-2xl bg-amber-50 flex items-center justify-center text-amber-600">
              <Clock size={24} />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Em Recurso</div>
              <div className="text-2xl font-bold text-slate-900">R$ {(summary.total_em_recurso || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
            </div>
          </div>
          <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-amber-500" style={{ width: `${((summary.total_em_recurso || 0) / (summary.total_glosado || 1) * 100) || 0}%` }}></div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="h-12 w-12 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-600">
              <Ban size={24} />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Glosa Definitiva</div>
              <div className="text-2xl font-bold text-slate-900">R$ {(summary.total_definitivo || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
            </div>
          </div>
          <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-slate-900" style={{ width: `${((summary.total_definitivo || 0) / (summary.total_glosado || 1) * 100) || 0}%` }}></div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-wrap gap-4 items-center">
        <div className="flex items-center gap-2 text-slate-400 mr-2">
          <Filter size={18} />
          <span className="text-xs font-bold uppercase tracking-widest">Filtros</span>
        </div>
        
        <select 
          className="bg-slate-50 border-none rounded-xl text-xs font-medium focus:ring-indigo-500 p-2.5"
          value={filters.clinic_id}
          onChange={e => setFilters({...filters, clinic_id: e.target.value})}
        >
          <option value="">Todas as Clínicas</option>
          {clinics.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>

        <select 
          className="bg-slate-50 border-none rounded-xl text-xs font-medium focus:ring-indigo-500 p-2.5"
          value={filters.insurance_id}
          onChange={e => setFilters({...filters, insurance_id: e.target.value})}
        >
          <option value="">Todos os Convênios</option>
          {insurances.map(i => <option key={i.id} value={i.id}>{i.name}</option>)}
        </select>

        <select 
          className="bg-slate-50 border-none rounded-xl text-xs font-medium focus:ring-indigo-500 p-2.5"
          value={filters.status}
          onChange={e => setFilters({...filters, status: e.target.value})}
        >
          <option value="">Todos os Status</option>
          <option value="A_FATURAR">A Faturar</option>
          <option value="EM_ABERTO">Em Aberto</option>
          <option value="GLOSADO">Glosado</option>
          <option value="RECEBIDO">Recebido</option>
        </select>

        <button 
          onClick={() => setFilters({ clinic_id: '', insurance_id: '', professional_id: '', status: '' })}
          className="ml-auto text-xs font-bold text-indigo-600 hover:text-indigo-700"
        >
          Limpar Filtros
        </button>
      </div>

      {/* Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Data / Paciente</th>
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Convênio / Proc.</th>
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Valor Bruto</th>
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Status Pgto</th>
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Info Glosa</th>
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400 text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {productions.map((prod) => (
              <tr key={prod.id} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-6 py-4">
                  <div className="text-sm font-bold text-slate-900">{prod.patient_name || 'Paciente não informado'}</div>
                  <div className="text-[10px] text-slate-500 font-medium uppercase tracking-wider">
                    {prod.date ? new Date(prod.date).toLocaleDateString('pt-BR') : '-'}
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm font-medium text-slate-700">{prod.insurance_name || '-'}</div>
                  <div className="text-[10px] text-slate-400 font-medium uppercase">{prod.procedure_name || '-'}</div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm font-bold text-slate-900">R$ {(prod.value || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
                </td>
                <td className="px-6 py-4">
                  <span className={clsx(
                    "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest",
                    prod.payment_status === 'GLOSADO' ? "bg-red-50 text-red-600" :
                    prod.payment_status === 'RECEBIDO' ? "bg-emerald-50 text-emerald-600" :
                    "bg-slate-100 text-slate-500"
                  )}>
                    {prod.payment_status}
                  </span>
                </td>
                <td className="px-6 py-4">
                  {prod.payment_status === 'GLOSADO' ? (
                    <div>
                      <div className="text-xs font-bold text-red-600">R$ {(prod.glosa_value || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
                      <div className="text-[10px] text-slate-500 italic truncate max-w-[150px]">{prod.glosa_reason || '-'}</div>
                      <div className="text-[9px] font-bold uppercase text-amber-600 mt-1">{prod.glosa_status || '-'}</div>
                    </div>
                  ) : (
                    <span className="text-slate-300 text-xs">-</span>
                  )}
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex justify-end gap-2">
                    {prod.payment_status === 'GLOSADO' ? (
                      <>
                        <button 
                          onClick={() => handleRevert(prod.id)}
                          className="flex items-center gap-1 px-3 py-1.5 bg-emerald-50 text-emerald-600 rounded-lg text-[10px] font-bold hover:bg-emerald-100 transition-all"
                        >
                          <RotateCcw size={14} />
                          REVERTER
                        </button>
                        <button 
                          onClick={() => {
                            setSelectedProd(prod);
                            setGlosaForm({ 
                              value: (prod.glosa_value || 0).toString(), 
                              reason: prod.glosa_reason || '', 
                              status: prod.glosa_status || 'EM_RECURSO' 
                            });
                          }}
                          className="p-1.5 text-slate-400 hover:text-slate-600"
                        >
                          <MoreVertical size={18} />
                        </button>
                      </>
                    ) : (
                      <button 
                        onClick={() => {
                          setSelectedProd(prod);
                          setGlosaForm({ 
                            value: (prod.value || 0).toString(), 
                            reason: '', 
                            status: 'EM_RECURSO' 
                          });
                        }}
                        className="flex items-center gap-1 px-3 py-1.5 border border-red-100 text-red-600 rounded-lg text-[10px] font-bold hover:bg-red-50 transition-all"
                      >
                        <Ban size={14} />
                        GLOSAR
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Glosa Modal */}
      {selectedProd && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-slate-100">
              <h3 className="text-xl font-bold text-slate-900">Registrar Glosa</h3>
              <p className="text-slate-500 text-sm">Preencha os detalhes da negativa do convênio.</p>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Valor Glosado</label>
                <div className="flex items-center gap-2 px-4 py-3 bg-slate-50 rounded-2xl border border-slate-100">
                  <span className="text-slate-400 font-bold">R$</span>
                  <input 
                    type="number" 
                    className="bg-transparent border-none w-full focus:ring-0 font-bold text-slate-900"
                    value={glosaForm.value}
                    onChange={e => setGlosaForm({...glosaForm, value: e.target.value})}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Motivo da Glosa</label>
                <textarea 
                  className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-4 text-sm focus:ring-indigo-500 min-h-[100px]"
                  placeholder="Ex: Guia sem assinatura, Procedimento não autorizado..."
                  value={glosaForm.reason}
                  onChange={e => setGlosaForm({...glosaForm, reason: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Status do Recurso</label>
                <div className="grid grid-cols-2 gap-3">
                  <button 
                    onClick={() => setGlosaForm({...glosaForm, status: 'EM_RECURSO'})}
                    className={clsx(
                      "px-4 py-3 rounded-2xl text-xs font-bold border transition-all",
                      glosaForm.status === 'EM_RECURSO' ? "bg-amber-50 border-amber-200 text-amber-700" : "bg-white border-slate-200 text-slate-500"
                    )}
                  >
                    Em Recurso
                  </button>
                  <button 
                    onClick={() => setGlosaForm({...glosaForm, status: 'DEFINITIVO'})}
                    className={clsx(
                      "px-4 py-3 rounded-2xl text-xs font-bold border transition-all",
                      glosaForm.status === 'DEFINITIVO' ? "bg-red-50 border-red-200 text-red-700" : "bg-white border-slate-200 text-slate-500"
                    )}
                  >
                    Definitivo
                  </button>
                </div>
              </div>
            </div>

            <div className="p-6 bg-slate-50 flex gap-3">
              <button 
                onClick={() => setSelectedProd(null)}
                className="flex-1 px-4 py-3 rounded-2xl text-xs font-bold text-slate-500 hover:bg-slate-100 transition-all"
              >
                Cancelar
              </button>
              <button 
                onClick={handleMarkGlosa}
                className="flex-1 px-4 py-3 rounded-2xl text-xs font-bold bg-indigo-600 text-white shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all"
              >
                Confirmar Glosa
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
