import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  UserRound, 
  ShieldCheck, 
  Activity, 
  Scale, 
  Plus, 
  Save, 
  Trash2,
  ChevronRight,
  Search
} from 'lucide-react';
import { clsx } from 'clsx';

type Tab = 'clinics' | 'professionals' | 'insurances' | 'procedures' | 'rules' | 'users';

export const MasterRegistration: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('clinics');
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState<any>({});
  const [user, setUser] = useState<any>(null);

  // Auxiliares para os selects nas regras
  const [clinics, setClinics] = useState<any[]>([]);
  const [insurances, setInsurances] = useState<any[]>([]);
  const [procedures, setProcedures] = useState<any[]>([]);
  const [professionals, setProfessionals] = useState<any[]>([]);

  useEffect(() => {
    const session = localStorage.getItem('fluxosaude_session');
    if (session) setUser(JSON.parse(session).user);
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const endpoint = activeTab === 'rules' ? '/api/rules' : 
                      activeTab === 'users' ? '/api/users' :
                      `/api/${activeTab.replace('insurances', 'health-insurances')}`;
      const response = await fetch(endpoint);
      const result = await response.json();
      setData(result);

      // Carregar auxiliares se estiver na aba de regras ou usuários
      if (activeTab === 'rules' || activeTab === 'users') {
        const [c, i, p] = await Promise.all([
          fetch('/api/clinics').then(r => r.json()),
          fetch('/api/health-insurances').then(r => r.json()),
          fetch('/api/professionals').then(r => r.json())
        ]);
        setClinics(c);
        setInsurances(i);
        setProfessionals(p);
        
        if (activeTab === 'rules') {
          const pr = await fetch('/api/procedures').then(r => r.json());
          setProcedures(pr);
        }
      }
    } catch (error) {
      console.error("Erro ao buscar dados:", error);
    }
    setLoading(false);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const endpoint = activeTab === 'rules' ? '/api/rules' : 
                      activeTab === 'users' ? '/api/users' :
                      `/api/${activeTab.replace('insurances', 'health-insurances')}`;
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, userId: user?.id })
      });

      if (response.ok) {
        setShowModal(false);
        setFormData({});
        fetchData();
      }
    } catch (error) {
      console.error("Erro ao salvar:", error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm("Tem certeza que deseja excluir este item?")) return;
    
    const endpoint = activeTab === 'rules' ? '/api/rules' : 
                    activeTab === 'users' ? '/api/users' :
                    `/api/${activeTab.replace('insurances', 'health-insurances')}`;
    try {
      const response = await fetch(`${endpoint}/${id}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user?.id })
      });

      if (response.ok) {
        fetchData();
      }
    } catch (error) {
      console.error("Erro ao deletar:", error);
    }
  };

  const tabs = [
    { id: 'clinics', label: 'Clínicas', icon: Building2 },
    { id: 'professionals', label: 'Profissionais', icon: UserRound },
    { id: 'insurances', label: 'Convênios', icon: ShieldCheck },
    { id: 'procedures', label: 'Procedimentos', icon: Activity },
    { id: 'rules', label: 'Regras de Taxa', icon: Scale },
    { id: 'users', label: 'Usuários', icon: UserRound },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Cadastros Mestre</h1>
          <p className="text-slate-500 text-sm">Gerencie as entidades base do sistema e regras automáticas.</p>
        </div>
        <button 
          onClick={() => {
            setFormData({});
            setShowModal(true);
          }}
          className="flex items-center justify-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
        >
          <Plus size={18} />
          Novo Cadastro
        </button>
      </div>

      {/* Tabs Responsivas */}
      <div className="flex overflow-x-auto pb-2 gap-2 no-scrollbar">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as Tab)}
            className={clsx(
              "flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold whitespace-nowrap transition-all border-2",
              activeTab === tab.id 
                ? "bg-white border-indigo-600 text-indigo-600 shadow-sm" 
                : "bg-slate-50 border-transparent text-slate-500 hover:bg-white hover:border-slate-200"
            )}
          >
            <tab.icon size={18} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Listagem */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-200">
                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Informações</th>
                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Detalhes</th>
                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={3} className="px-6 py-12 text-center">
                    <div className="h-8 w-8 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mx-auto"></div>
                  </td>
                </tr>
              ) : data.length === 0 ? (
                <tr>
                  <td colSpan={3} className="px-6 py-12 text-center text-slate-400 text-sm">Nenhum registro encontrado.</td>
                </tr>
              ) : (
                data.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="text-sm font-bold text-slate-900">
                        {activeTab === 'rules' ? `Regra #${item.id}` : item.name}
                      </div>
                      <div className="text-[10px] text-slate-500 font-medium uppercase tracking-wider">
                        {activeTab === 'clinics' && item.cnpj}
                        {activeTab === 'professionals' && item.crm}
                        {activeTab === 'procedures' && item.code}
                        {activeTab === 'rules' && item.clinic_name}
                        {activeTab === 'users' && item.username}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-xs text-slate-600">
                        {activeTab === 'professionals' && item.email}
                        {activeTab === 'procedures' && `Valor Base: R$ ${item.default_value || 0}`}
                        {activeTab === 'users' && `Perfil: ${item.role}`}
                        {activeTab === 'rules' && (
                          <div className="space-y-1">
                            <div>Convênio: {item.insurance_name || 'Todos'}</div>
                            <div>Taxa: {item.fee_percent}% + R$ {item.fixed_fee || 0}</div>
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => handleDelete(item.id)}
                        className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal de Cadastro */}
      {showModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900">Novo {tabs.find(t => t.id === activeTab)?.label}</h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                <Plus size={24} className="rotate-45" />
              </button>
            </div>
            <form onSubmit={handleSave} className="p-6 space-y-4">
              {activeTab === 'clinics' && (
                <>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Nome da Clínica</label>
                    <input 
                      required
                      type="text" 
                      className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                      onChange={e => setFormData({...formData, name: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">CNPJ</label>
                    <input 
                      type="text" 
                      className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                      onChange={e => setFormData({...formData, cnpj: e.target.value})}
                    />
                  </div>
                </>
              )}

              {activeTab === 'professionals' && (
                <>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Nome do Profissional</label>
                    <input 
                      required
                      type="text" 
                      className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                      onChange={e => setFormData({...formData, name: e.target.value})}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">CRM</label>
                      <input 
                        type="text" 
                        className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                        onChange={e => setFormData({...formData, crm: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Email</label>
                      <input 
                        type="email" 
                        className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                        onChange={e => setFormData({...formData, email: e.target.value})}
                      />
                    </div>
                  </div>
                </>
              )}

              {activeTab === 'insurances' && (
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Nome do Convênio</label>
                  <input 
                    required
                    type="text" 
                    className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                    onChange={e => setFormData({...formData, name: e.target.value})}
                  />
                </div>
              )}

              {activeTab === 'procedures' && (
                <>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Nome do Procedimento</label>
                    <input 
                      required
                      type="text" 
                      className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                      onChange={e => setFormData({...formData, name: e.target.value})}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Código TUSS</label>
                      <input 
                        type="text" 
                        className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                        onChange={e => setFormData({...formData, code: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Valor Base</label>
                      <input 
                        type="number" 
                        step="0.01"
                        className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                        onChange={e => setFormData({...formData, default_value: e.target.value})}
                      />
                    </div>
                  </div>
                </>
              )}

              {activeTab === 'rules' && (
                <>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Clínica</label>
                    <select 
                      required
                      className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                      onChange={e => setFormData({...formData, clinic_id: e.target.value})}
                    >
                      <option value="">Selecione a Clínica</option>
                      {clinics.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Convênio (Opcional)</label>
                      <select 
                        className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                        onChange={e => setFormData({...formData, health_insurance_id: e.target.value})}
                      >
                        <option value="">Todos</option>
                        {insurances.map(i => <option key={i.id} value={i.id}>{i.name}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Procedimento (Opcional)</label>
                      <select 
                        className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                        onChange={e => setFormData({...formData, procedure_id: e.target.value})}
                      >
                        <option value="">Todos</option>
                        {procedures.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Taxa (%)</label>
                      <input 
                        type="number" 
                        step="0.1"
                        className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                        onChange={e => setFormData({...formData, fee_percent: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Taxa Fixa (R$)</label>
                      <input 
                        type="number" 
                        step="0.01"
                        className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                        onChange={e => setFormData({...formData, fixed_fee: e.target.value})}
                      />
                    </div>
                  </div>
                </>
              )}

              {activeTab === 'users' && (
                <>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Username</label>
                    <input 
                      required
                      type="text" 
                      className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                      onChange={e => setFormData({...formData, username: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Senha</label>
                    <input 
                      required
                      type="password" 
                      className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                      onChange={e => setFormData({...formData, password: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Perfil</label>
                    <select 
                      required
                      className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                      onChange={e => setFormData({...formData, role: e.target.value})}
                    >
                      <option value="">Selecione o Perfil</option>
                      <option value="ADMIN">ADMIN</option>
                      <option value="BPO">BPO</option>
                      <option value="MEDICO">MEDICO</option>
                      <option value="GESTOR">GESTOR</option>
                      <option value="CLINICA">CLINICA</option>
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Profissional (Se Médico)</label>
                      <select 
                        className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                        onChange={e => setFormData({...formData, professional_id: e.target.value})}
                      >
                        <option value="">Nenhum</option>
                        {professionals.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Clínica (Se Gestor/Clínica)</label>
                      <select 
                        className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"
                        onChange={e => setFormData({...formData, clinic_id: e.target.value})}
                      >
                        <option value="">Nenhuma</option>
                        {clinics.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>
                    </div>
                  </div>
                </>
              )}

              <div className="pt-4">
                <button 
                  type="submit"
                  className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold text-sm hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 flex items-center justify-center gap-2"
                >
                  <Save size={18} />
                  Salvar Cadastro
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
