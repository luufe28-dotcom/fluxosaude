import React, { useState, useEffect } from 'react';
import { 
  Wallet, 
  Plus, 
  CheckCircle2, 
  Clock, 
  DollarSign, 
  Filter,
  ChevronRight,
  FileText,
  Building2,
  User,
  ArrowRight,
  X
} from 'lucide-react';
import { clsx } from 'clsx';

export const TransfersManagement: React.FC = () => {
  const [transfers, setTransfers] = useState<any[]>([]);
  const [clinics, setClinics] = useState<any[]>([]);
  const [professionals, setProfessionals] = useState<any[]>([]);
  const [filters, setFilters] = useState({ clinic_id: '', professional_id: '', status: '' });
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [genForm, setGenForm] = useState({ professional_id: '', clinic_id: '', start_date: '', end_date: '', tax: '30' });
  const [eligibleProds, setEligibleProds] = useState<any[]>([]);
  const [selectedProds, setSelectedProds] = useState<number[]>([]);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const session = localStorage.getItem('fluxosaude_session');
    if (session) setUser(JSON.parse(session).user);
  }, []);

  const fetchData = async () => {
    const query = new URLSearchParams(filters).toString();
    const [t, c, p] = await Promise.all([
      fetch(`/api/transfers?${query}`).then(r => r.json()),
      fetch('/api/clinics').then(r => r.json()),
      fetch('/api/professionals').then(r => r.json())
    ]);
    setTransfers(t);
    setClinics(c);
    setProfessionals(p);
  };

  useEffect(() => {
    fetchData();
  }, [filters]);

  const fetchEligible = async () => {
    if (!genForm.professional_id || !genForm.clinic_id || !genForm.start_date || !genForm.end_date) return;
    const query = new URLSearchParams(genForm).toString();
    const data = await fetch(`/api/transfers/eligible-productions?${query}`).then(r => r.json());
    setEligibleProds(data);
    setSelectedProds(data.map((p: any) => p.id));
  };

  const handleGenerate = async () => {
    const response = await fetch('/api/transfers/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...genForm,
        production_ids: selectedProds,
        clinic_tax_percent: parseFloat(genForm.tax),
        userId: user?.id
      })
    });
    if (response.ok) {
      setIsGenerating(false);
      fetchData();
    }
  };

  const updateStatus = async (id: number, status: string) => {
    const response = await fetch(`/api/transfers/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, userId: user?.id })
    });
    if (response.ok) fetchData();
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Gestão de Repasses</h1>
          <p className="text-slate-500 text-sm">Controle de lotes de pagamento aos profissionais.</p>
        </div>
        <button 
          onClick={() => setIsGenerating(true)}
          className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-2xl font-bold text-sm shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all"
        >
          <Plus size={18} />
          Gerar Novo Lote
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-wrap gap-4 items-center shadow-sm">
        <div className="flex items-center gap-2 text-slate-400 mr-2">
          <Filter size={18} />
          <span className="text-xs font-bold uppercase tracking-widest">Filtros</span>
        </div>
        
        <select 
          className="bg-slate-50 border-none rounded-xl text-xs font-medium focus:ring-indigo-500 p-2.5"
          value={filters.clinic_id}
          onChange={e => setFilters({...filters, clinic_id: e.target.value})}
        >
          <option value="">Todas as Clínicas</option>
          {clinics.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>

        <select 
          className="bg-slate-50 border-none rounded-xl text-xs font-medium focus:ring-indigo-500 p-2.5"
          value={filters.professional_id}
          onChange={e => setFilters({...filters, professional_id: e.target.value})}
        >
          <option value="">Todos os Profissionais</option>
          {professionals.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>

        <select 
          className="bg-slate-50 border-none rounded-xl text-xs font-medium focus:ring-indigo-500 p-2.5"
          value={filters.status}
          onChange={e => setFilters({...filters, status: e.target.value})}
        >
          <option value="">Todos os Status</option>
          <option value="PENDENTE">Pendente</option>
          <option value="APROVADO">Aprovado</option>
          <option value="PAGO">Pago</option>
        </select>
      </div>

      {/* Transfers List */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[1000px]">
            <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Profissional / Clínica</th>
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Período</th>
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Bruto / Taxa</th>
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Valor Líquido</th>
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Status</th>
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400 text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {transfers.map((t) => (
              <tr key={t.id} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-6 py-4">
                  <div className="text-sm font-bold text-slate-900">{t.professional_name}</div>
                  <div className="text-[10px] text-slate-500 font-medium uppercase tracking-wider">{t.clinic_name}</div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-xs font-medium text-slate-600">
                    {new Date(t.period_start).toLocaleDateString('pt-BR')} - {new Date(t.period_end).toLocaleDateString('pt-BR')}
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm font-medium text-slate-700">R$ {t.gross_value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
                  <div className="text-[10px] text-red-500 font-bold">- R$ {t.clinic_tax.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-base font-bold text-indigo-600">R$ {t.net_value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
                </td>
                <td className="px-6 py-4">
                  <span className={clsx(
                    "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest",
                    t.status === 'PAGO' ? "bg-emerald-50 text-emerald-600" :
                    t.status === 'APROVADO' ? "bg-indigo-50 text-indigo-600" :
                    "bg-amber-50 text-amber-600"
                  )}>
                    {t.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex justify-end gap-2">
                    {t.status === 'PENDENTE' && (
                      <button 
                        onClick={() => updateStatus(t.id, 'APROVADO')}
                        className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-[10px] font-bold hover:bg-indigo-700 transition-all"
                      >
                        ENVIAR PARA APROVAÇÃO
                      </button>
                    )}
                    {t.status === 'APROVADO' && (
                      <button 
                        onClick={() => updateStatus(t.id, 'PAGO')}
                        className="px-3 py-1.5 bg-emerald-600 text-white rounded-lg text-[10px] font-bold hover:bg-emerald-700 transition-all"
                      >
                        MARCAR COMO PAGO
                      </button>
                    )}
                    <button className="p-1.5 text-slate-400 hover:text-slate-600">
                      <FileText size={18} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>

      {/* Generate Batch Modal */}
      {isGenerating && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <div>
                <h3 className="text-xl font-bold text-slate-900">Gerar Lote de Repasse</h3>
                <p className="text-slate-500 text-sm">Selecione o profissional e o período para calcular o repasse.</p>
              </div>
              <button onClick={() => setIsGenerating(false)} className="p-2 hover:bg-slate-100 rounded-full text-slate-400">
                <X size={20} />
              </button>
            </div>
            
            <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-8 overflow-y-auto">
              {/* Config Form */}
              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Profissional</label>
                  <select 
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-3 text-sm focus:ring-indigo-500"
                    value={genForm.professional_id}
                    onChange={e => setGenForm({...genForm, professional_id: e.target.value})}
                  >
                    <option value="">Selecione...</option>
                    {professionals.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Clínica</label>
                  <select 
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-3 text-sm focus:ring-indigo-500"
                    value={genForm.clinic_id}
                    onChange={e => setGenForm({...genForm, clinic_id: e.target.value})}
                  >
                    <option value="">Selecione...</option>
                    {clinics.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Início</label>
                    <input 
                      type="date" 
                      className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-3 text-sm focus:ring-indigo-500"
                      value={genForm.start_date}
                      onChange={e => setGenForm({...genForm, start_date: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Fim</label>
                    <input 
                      type="date" 
                      className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-3 text-sm focus:ring-indigo-500"
                      value={genForm.end_date}
                      onChange={e => setGenForm({...genForm, end_date: e.target.value})}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Taxa da Clínica (%)</label>
                  <input 
                    type="number" 
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-3 text-sm focus:ring-indigo-500 font-bold"
                    value={genForm.tax}
                    onChange={e => setGenForm({...genForm, tax: e.target.value})}
                  />
                </div>
                <button 
                  onClick={fetchEligible}
                  className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold text-sm hover:bg-slate-800 transition-all"
                >
                  Buscar Produções
                </button>
              </div>

              {/* Eligible Productions List */}
              <div className="lg:col-span-2 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-900">Produções Elegíveis ({eligibleProds.length})</h4>
                  <div className="text-[10px] font-bold text-indigo-600 uppercase">Status: Recebido</div>
                </div>
                
                <div className="border border-slate-100 rounded-2xl overflow-hidden">
                  <div className="max-h-[300px] overflow-y-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 sticky top-0">
                        <tr>
                          <th className="p-3"><input type="checkbox" checked={selectedProds.length === eligibleProds.length} readOnly /></th>
                          <th className="p-3">Data</th>
                          <th className="p-3">Paciente</th>
                          <th className="p-3">Procedimento</th>
                          <th className="p-3 text-right">Valor</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {eligibleProds.map(p => (
                          <tr key={p.id}>
                            <td className="p-3">
                              <input 
                                type="checkbox" 
                                checked={selectedProds.includes(p.id)}
                                onChange={(e) => {
                                  if (e.target.checked) setSelectedProds([...selectedProds, p.id]);
                                  else setSelectedProds(selectedProds.filter(id => id !== p.id));
                                }}
                              />
                            </td>
                            <td className="p-3">{new Date(p.date).toLocaleDateString('pt-BR')}</td>
                            <td className="p-3 font-medium">{p.patient_name}</td>
                            <td className="p-3 text-slate-500">{p.procedure_name}</td>
                            <td className="p-3 text-right font-bold">R$ {p.value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                          </tr>
                        ))}
                        {eligibleProds.length === 0 && (
                          <tr>
                            <td colSpan={5} className="p-8 text-center text-slate-400 italic">Nenhuma produção elegível encontrada para este período.</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                {eligibleProds.length > 0 && (
                  <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100">
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <div className="text-[10px] font-bold uppercase text-indigo-400 mb-1">Total Bruto</div>
                        <div className="text-lg font-bold text-indigo-900">
                          R$ {eligibleProds.filter(p => selectedProds.includes(p.id)).reduce((acc, p) => acc + p.value, 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </div>
                      </div>
                      <div>
                        <div className="text-[10px] font-bold uppercase text-indigo-400 mb-1">Taxa Clínica ({genForm.tax}%)</div>
                        <div className="text-lg font-bold text-red-600">
                          - R$ {(eligibleProds.filter(p => selectedProds.includes(p.id)).reduce((acc, p) => acc + p.value, 0) * (parseFloat(genForm.tax) / 100)).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </div>
                      </div>
                      <div>
                        <div className="text-[10px] font-bold uppercase text-indigo-400 mb-1">Líquido Médico</div>
                        <div className="text-xl font-bold text-emerald-600">
                          R$ {(eligibleProds.filter(p => selectedProds.includes(p.id)).reduce((acc, p) => acc + p.value, 0) * (1 - parseFloat(genForm.tax) / 100)).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="p-6 bg-slate-50 flex gap-3">
              <button 
                onClick={() => setIsGenerating(false)}
                className="flex-1 px-4 py-3 rounded-2xl text-xs font-bold text-slate-500 hover:bg-slate-100 transition-all"
              >
                Cancelar
              </button>
              <button 
                disabled={selectedProds.length === 0}
                onClick={handleGenerate}
                className="flex-1 px-4 py-3 rounded-2xl text-xs font-bold bg-indigo-600 text-white shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all disabled:opacity-50"
              >
                Gerar e Enviar para Aprovação
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
