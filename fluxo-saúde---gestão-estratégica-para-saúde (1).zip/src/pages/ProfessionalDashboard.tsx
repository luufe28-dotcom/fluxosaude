import React from 'react';
import { 
  TrendingUp, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Calculator,
  ChevronRight,
  Filter,
  Info
} from 'lucide-react';
import { DashboardCard } from '../components/DashboardCard';
import { motion } from 'motion/react';
import { clsx } from 'clsx';

export const ProfessionalDashboard: React.FC = () => {
  const [stats, setStats] = React.useState<any>(null);
  const [recentProductions, setRecentProductions] = React.useState<any[]>([]);
  const [user, setUser] = React.useState<any>(null);

  React.useEffect(() => {
    const session = localStorage.getItem('fluxosaude_session');
    if (session) {
      const data = JSON.parse(session);
      setUser(data.user);
    }
  }, []);

  React.useEffect(() => {
    if (!user) return;

    const fetchData = async () => {
      try {
        // Para o dashboard profissional, filtramos pelo ID do profissional logado
        // Se for admin, mostramos tudo (ou poderíamos filtrar por um profissional específico)
        const profId = user.role === 'ADMIN' ? '' : user.id;
        const [s, p] = await Promise.all([
          fetch(`/api/manager/stats?professional_id=${profId}`).then(r => r.json()),
          fetch('/api/productions').then(r => r.json())
        ]);
        setStats(s);
        // Filtrar produções recentes do profissional
        const filtered = user.role === 'ADMIN' ? p : p.filter((item: any) => item.professional_id === user.id);
        setRecentProductions(filtered.slice(0, 5));
      } catch (e) {
        console.error("Erro ao carregar dashboard", e);
      }
    };
    fetchData();
  }, [user]);

  if (!stats) return <div className="p-8 text-center text-slate-500">Carregando dados...</div>;

  return (
    <div className="space-y-8">
      <header className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Olá, {user?.username}</h1>
          <p className="text-slate-500">Aqui está o resumo da sua produção em tempo real.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50">
            <Filter size={16} />
            Todas as Clínicas
          </button>
          <button className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700">
            Ver Extrato Completo
          </button>
        </div>
      </header>

      {/* Alerta de Dividendos */}
      <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="rounded-xl border border-amber-200 bg-amber-50 p-4 flex gap-3 items-start"
      >
        <AlertCircle className="text-amber-600 mt-0.5" size={20} />
        <div>
          <h4 className="text-sm font-bold text-amber-900">⚠️ Atenção ao seu limite de retirada</h4>
          <p className="text-sm text-amber-800 mt-1">
            Sua retirada de lucros este mês está próxima do limite de isenção. Pelas novas regras, valores acima deste patamar podem sofrer tributação de 10%. Recomendamos conversar com seu consultor BPO.
          </p>
        </div>
      </motion.div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
        <DashboardCard
          title="Produção Total"
          value={`R$ ${(stats.gross_billing || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          subtitle="Tudo o que você atendeu."
          tooltip="É a soma de todos os seus atendimentos realizados, antes de qualquer desconto, taxa ou glosa."
          icon={TrendingUp}
        />
        <DashboardCard
          title="Valores Recebidos"
          value={`R$ ${(stats.total_received || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          subtitle="Confirmado pelos convênios."
          tooltip="São os valores que as operadoras de saúde já pagaram."
          icon={CheckCircle2}
          variant="success"
        />
        <DashboardCard
          title="Pagamentos em Aberto"
          value={`R$ ${(stats.total_pending || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          subtitle="Aguardando prazo."
          tooltip="São atendimentos que já foram faturados, mas que o convênio ainda está dentro do prazo para pagar."
          icon={Clock}
        />
        <DashboardCard
          title="Glosas (Contestações)"
          value={`R$ ${(stats.total_glosas || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          subtitle="Valores recusados."
          tooltip="Representa atendimentos que tiveram o pagamento negado. Nossa equipe já iniciou o processo de recurso."
          icon={AlertCircle}
          variant="error"
        />
        <DashboardCard
          title="Reserva de Impostos"
          value={`R$ ${(stats.gross_billing * 0.15 || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          subtitle="Estimativa fiscal (15%)."
          tooltip="Calculamos quanto você precisará reservar para impostos com base no faturamento."
          icon={Calculator}
          variant="warning"
        />
      </div>

      <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold text-slate-900">Últimos Atendimentos</h2>
          <button className="text-sm font-medium text-indigo-600 hover:underline">Ver todos</button>
        </div>
        <div className="overflow-x-auto -mx-6 px-6">
          <table className="w-full text-left text-sm min-w-[600px]">
            <thead>
              <tr className="border-b border-slate-100 text-slate-400">
                <th className="pb-3 font-medium">Data</th>
                <th className="pb-3 font-medium">Paciente</th>
                <th className="pb-3 font-medium">Profissional</th>
                <th className="pb-3 font-medium">Valor Bruto</th>
                <th className="pb-3 font-medium">Taxa BPO</th>
                <th className="pb-3 font-medium text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {recentProductions.map((row, i) => (
                <tr key={i} className="group hover:bg-slate-50/50 transition-colors">
                  <td className="py-4 text-slate-600">{new Date(row.date).toLocaleDateString('pt-BR')}</td>
                  <td className="py-4 font-medium text-slate-900">{row.patient_name}</td>
                  <td className="py-4 text-slate-600">{row.professional_name}</td>
                  <td className="py-4 font-semibold text-slate-900">R$ {row.value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                  <td className="py-4 text-slate-500">R$ {(row.fee_value || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                  <td className="py-4 text-right">
                    <span className={clsx(
                      "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
                      row.payment_status === 'RECEBIDO' ? "text-emerald-600 bg-emerald-50" :
                      row.payment_status === 'GLOSADO' ? "text-red-600 bg-red-50" :
                      "text-slate-600 bg-slate-100"
                    )}>
                      {row.payment_status}
                    </span>
                  </td>
                </tr>
              ))}
              {recentProductions.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-400 italic">Nenhum atendimento registrado.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
