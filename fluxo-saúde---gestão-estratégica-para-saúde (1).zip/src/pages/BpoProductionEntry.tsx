import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  Copy, 
  Save, 
  AlertCircle,
  CheckCircle2,
  Calendar as CalendarIcon,
  ChevronDown
} from 'lucide-react';
import { clsx } from 'clsx';

interface ProductionRow {
  id: string;
  date: string;
  clinic_id: string;
  professional_id: string;
  health_insurance_id: string;
  procedure_id: string;
  patient_name: string;
  value: string;
}

export const BpoProductionEntry: React.FC = () => {
  const [rows, setRows] = useState<ProductionRow[]>([
    { id: '1', date: new Date().toISOString().split('T')[0], clinic_id: '', professional_id: '', health_insurance_id: '', procedure_id: '', patient_name: '', value: '' }
  ]);

  const [clinics, setClinics] = useState<any[]>([]);
  const [professionals, setProfessionals] = useState<any[]>([]);
  const [insurances, setInsurances] = useState<any[]>([]);
  const [procedures, setProcedures] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const session = localStorage.getItem('fluxosaude_session');
    if (session) setUser(JSON.parse(session).user);

    const fetchData = async () => {
      const [c, p, i, pr] = await Promise.all([
        fetch('/api/clinics').then(r => r.json()),
        fetch('/api/professionals').then(r => r.json()),
        fetch('/api/health-insurances').then(r => r.json()),
        fetch('/api/procedures').then(r => r.json())
      ]);
      setClinics(c);
      setProfessionals(p);
      setInsurances(i);
      setProcedures(pr);
    };
    fetchData();
  }, []);

  const addRow = () => {
    const lastRow = rows[rows.length - 1];
    setRows([...rows, { 
      ...lastRow, 
      id: Math.random().toString(36).substr(2, 9),
      patient_name: '',
      value: ''
    }]);
  };

  const duplicateRow = (index: number) => {
    const newRow = { ...rows[index], id: Math.random().toString(36).substr(2, 9) };
    const newRows = [...rows];
    newRows.splice(index + 1, 0, newRow);
    setRows(newRows);
  };

  const removeRow = (index: number) => {
    if (rows.length === 1) return;
    setRows(rows.filter((_, i) => i !== index));
  };

  const updateRow = (index: number, field: keyof ProductionRow, value: string) => {
    const newRows = [...rows];
    newRows[index] = { ...newRows[index], [field]: value };
    setRows(newRows);
  };

  const handleSave = async () => {
    setLoading(true);
    setMessage(null);
    try {
      const response = await fetch('/api/productions/batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          productions: rows,
          userId: user?.id
        })
      });
      
      const result = await response.json();
      if (result.success) {
        setMessage({ type: 'success', text: 'Lote de produção salvo com sucesso!' });
        setRows([{ id: '1', date: new Date().toISOString().split('T')[0], clinic_id: '', professional_id: '', health_insurance_id: '', procedure_id: '', patient_name: '', value: '' }]);
      } else {
        setMessage({ type: 'error', text: result.error || 'Erro ao salvar lote.' });
      }
    } catch (e) {
      setMessage({ type: 'error', text: 'Erro de conexão com o servidor.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Lançamento de Produção</h1>
          <p className="text-slate-500 text-sm">Insira os atendimentos realizados para processamento do BPO.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={addRow}
            className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 transition-all"
          >
            <Plus size={18} />
            Adicionar Linha
          </button>
          <button 
            onClick={handleSave}
            disabled={loading}
            className="flex items-center gap-2 px-6 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all disabled:opacity-50"
          >
            <Save size={18} />
            {loading ? 'Salvando...' : 'Salvar Lote'}
          </button>
        </div>
      </div>

      {message && (
        <div className={clsx(
          "p-4 rounded-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2",
          message.type === 'success' ? "bg-emerald-50 text-emerald-700 border border-emerald-100" : "bg-red-50 text-red-700 border border-red-100"
        )}>
          {message.type === 'success' ? <CheckCircle2 size={20} /> : <AlertCircle size={20} />}
          <span className="text-sm font-medium">{message.text}</span>
        </div>
      )}

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[1000px]">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-4 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Data</th>
                <th className="px-4 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Clínica</th>
                <th className="px-4 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Profissional</th>
                <th className="px-4 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Convênio</th>
                <th className="px-4 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Procedimento</th>
                <th className="px-4 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Paciente</th>
                <th className="px-4 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400 w-32">Valor Bruto</th>
                <th className="px-4 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400 w-24 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.map((row, index) => (
                <tr key={row.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="p-2">
                    <input 
                      type="date" 
                      value={row.date}
                      onChange={(e) => updateRow(index, 'date', e.target.value)}
                      className="w-full bg-transparent border-none text-sm focus:ring-0 p-2"
                    />
                  </td>
                  <td className="p-2">
                    <select 
                      value={row.clinic_id}
                      onChange={(e) => updateRow(index, 'clinic_id', e.target.value)}
                      className="w-full bg-transparent border-none text-sm focus:ring-0 p-2 appearance-none"
                    >
                      <option value="">Selecionar...</option>
                      {clinics.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </td>
                  <td className="p-2">
                    <select 
                      value={row.professional_id}
                      onChange={(e) => updateRow(index, 'professional_id', e.target.value)}
                      className="w-full bg-transparent border-none text-sm focus:ring-0 p-2 appearance-none"
                    >
                      <option value="">Selecionar...</option>
                      {professionals.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                  </td>
                  <td className="p-2">
                    <select 
                      value={row.health_insurance_id}
                      onChange={(e) => updateRow(index, 'health_insurance_id', e.target.value)}
                      className="w-full bg-transparent border-none text-sm focus:ring-0 p-2 appearance-none"
                    >
                      <option value="">Selecionar...</option>
                      {insurances.map(i => <option key={i.id} value={i.id}>{i.name}</option>)}
                    </select>
                  </td>
                  <td className="p-2">
                    <select 
                      value={row.procedure_id}
                      onChange={(e) => updateRow(index, 'procedure_id', e.target.value)}
                      className="w-full bg-transparent border-none text-sm focus:ring-0 p-2 appearance-none"
                    >
                      <option value="">Selecionar...</option>
                      {procedures.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                  </td>
                  <td className="p-2">
                    <input 
                      type="text" 
                      placeholder="Nome do Paciente"
                      value={row.patient_name}
                      onChange={(e) => updateRow(index, 'patient_name', e.target.value)}
                      className="w-full bg-transparent border-none text-sm focus:ring-0 p-2"
                    />
                  </td>
                  <td className="p-2">
                    <div className="flex items-center gap-1 px-2 border border-slate-100 rounded-lg bg-slate-50/50">
                      <span className="text-xs text-slate-400 font-bold">R$</span>
                      <input 
                        type="number" 
                        placeholder="0,00"
                        value={row.value}
                        onChange={(e) => updateRow(index, 'value', e.target.value)}
                        className="w-full bg-transparent border-none text-sm focus:ring-0 p-1.5 font-medium"
                      />
                    </div>
                  </td>
                  <td className="p-2">
                    <div className="flex items-center justify-center gap-1">
                      <button 
                        onClick={() => duplicateRow(index)}
                        className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                        title="Duplicar Linha"
                      >
                        <Copy size={16} />
                      </button>
                      <button 
                        onClick={() => removeRow(index)}
                        className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                        title="Excluir Linha"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center">
          <div className="text-xs text-slate-500 font-medium">
            Total de linhas: <span className="font-bold text-slate-900">{rows.length}</span>
          </div>
          <div className="text-xs text-slate-400 italic">
            Dica: Use o botão duplicar para repetir dados da linha anterior.
          </div>
        </div>
      </div>
    </div>
  );
};
