import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  AlertCircle, 
  Calendar,
  Building2,
  ChevronRight,
  ArrowUpRight,
  ArrowDownRight,
  Wallet,
  Filter
} from 'lucide-react';
import { clsx } from 'clsx';
import { Link } from 'react-router-dom';

export const ManagerDashboard: React.FC = () => {
  const [stats, setStats] = useState({
    gross_billing: 0,
    total_glosas: 0,
    glosa_rate: 0,
    net_estimated: 0,
    transfers_to_pay: 0,
    projected_cash: 0
  });
  const [insuranceData, setInsuranceData] = useState<any[]>([]);
  const [clinics, setClinics] = useState<any[]>([]);
  const [filters, setFilters] = useState({ clinic_id: '', start_date: '', end_date: '' });

  const fetchData = async () => {
    const query = new URLSearchParams(filters).toString();
    const [s, i, c] = await Promise.all([
      fetch(`/api/manager/stats?${query}`).then(r => r.json()),
      fetch(`/api/manager/billing-by-insurance?${query}`).then(r => r.json()),
      fetch('/api/clinics').then(r => r.json())
    ]);
    setStats(s);
    setInsuranceData(i);
    setClinics(c);
  };

  useEffect(() => {
    fetchData();
  }, [filters]);

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Painel do Gestor</h1>
          <p className="text-slate-500 text-sm">Visão consolidada da saúde financeira da clínica.</p>
        </div>
        <Link 
          to="/repasses"
          className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 transition-all shadow-sm"
        >
          Revisar Repasses Pendentes
          <ChevronRight size={16} />
        </Link>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-wrap gap-4 items-center shadow-sm">
        <div className="flex items-center gap-2 text-slate-400 mr-2">
          <Filter size={18} />
          <span className="text-xs font-bold uppercase tracking-widest">Filtros</span>
        </div>
        
        <select 
          className="bg-slate-50 border-none rounded-xl text-xs font-medium focus:ring-indigo-500 p-2.5"
          value={filters.clinic_id}
          onChange={e => setFilters({...filters, clinic_id: e.target.value})}
        >
          <option value="">Todas as Clínicas</option>
          {clinics.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>

        <div className="flex items-center gap-2">
          <input 
            type="date" 
            className="bg-slate-50 border-none rounded-xl text-xs font-medium focus:ring-indigo-500 p-2.5"
            value={filters.start_date}
            onChange={e => setFilters({...filters, start_date: e.target.value})}
          />
          <span className="text-slate-300">até</span>
          <input 
            type="date" 
            className="bg-slate-50 border-none rounded-xl text-xs font-medium focus:ring-indigo-500 p-2.5"
            value={filters.end_date}
            onChange={e => setFilters({...filters, end_date: e.target.value})}
          />
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          label="Faturamento Bruto" 
          value={stats.gross_billing || 0} 
          icon={TrendingUp} 
          color="indigo" 
        />
        <StatCard 
          label="Líquido Estimado" 
          value={stats.net_estimated || 0} 
          icon={DollarSign} 
          color="emerald" 
          subtitle="Bruto - Glosas"
        />
        <StatCard 
          label="Total Glosas" 
          value={stats.total_glosas || 0} 
          icon={TrendingDown} 
          color="red" 
          percentage={stats.glosa_rate || 0}
        />
        <StatCard 
          label="Repasses a Pagar" 
          value={stats.transfers_to_pay || 0} 
          icon={Wallet} 
          color="amber" 
          subtitle="Lotes pendentes"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Billing by Insurance Table */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-bold text-slate-900">Faturamento por Convênio</h3>
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Consolidado</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Convênio</th>
                  <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Bruto</th>
                  <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Glosado</th>
                  <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Líquido Est.</th>
                  <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">% Glosa</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(insuranceData || []).map((item, idx) => {
                  const gross = item.gross_billing || 0;
                  const glosas = item.total_glosas || 0;
                  const net = gross - glosas;
                  const rate = gross > 0 ? (glosas / gross) * 100 : 0;
                  return (
                    <tr key={idx} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 font-bold text-slate-900">{item.insurance_name}</td>
                      <td className="px-6 py-4 text-sm text-slate-600">R$ {gross.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                      <td className="px-6 py-4 text-sm text-red-600">R$ {glosas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                      <td className="px-6 py-4 text-sm font-bold text-emerald-600">R$ {net.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-12 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                            <div className="h-full bg-red-500" style={{ width: `${Math.min(rate, 100)}%` }}></div>
                          </div>
                          <span className="text-[10px] font-bold text-slate-400">{rate.toFixed(1)}%</span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Projected Cash */}
        <div className="bg-indigo-600 rounded-3xl p-8 text-white shadow-xl shadow-indigo-200 relative overflow-hidden">
          <div className="relative z-10">
            <div className="text-[10px] font-bold uppercase tracking-widest text-indigo-200 mb-2">Caixa Projetado</div>
            <div className="text-4xl font-bold mb-6">R$ {(stats.projected_cash || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
            <p className="text-indigo-100 text-sm leading-relaxed mb-8">
              Este valor considera o total já recebido menos os repasses que ainda precisam ser pagos aos profissionais.
            </p>
            <button className="w-full py-4 bg-white text-indigo-600 rounded-2xl font-bold text-sm hover:bg-indigo-50 transition-all">
              Ver Fluxo de Caixa
            </button>
          </div>
          <div className="absolute -right-12 -bottom-12 h-48 w-48 bg-white/10 rounded-full blur-3xl"></div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ label, value, icon: Icon, color, percentage, subtitle }: any) => {
  const colors: any = {
    indigo: "bg-indigo-50 text-indigo-600",
    emerald: "bg-emerald-50 text-emerald-600",
    red: "bg-red-50 text-red-600",
    amber: "bg-amber-50 text-amber-600"
  };

  return (
    <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className={clsx("h-10 w-10 rounded-xl flex items-center justify-center", colors[color])}>
          <Icon size={20} />
        </div>
        {percentage !== undefined && (
          <span className={clsx(
            "text-[10px] font-bold px-2 py-1 rounded-lg",
            percentage > 10 ? "bg-red-50 text-red-600" : "bg-emerald-50 text-emerald-600"
          )}>
            {percentage.toFixed(1)}%
          </span>
        )}
      </div>
      <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1">{label}</div>
      <div className="text-xl font-bold text-slate-900">R$ {value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
      {subtitle && <div className="text-[10px] text-slate-400 mt-1">{subtitle}</div>}
    </div>
  );
};
