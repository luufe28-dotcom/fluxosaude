import React from 'react';
import { LucideIcon } from 'lucide-react';
import { motion } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface DashboardCardProps {
  title: string;
  value: string;
  subtitle: string;
  tooltip: string;
  icon: LucideIcon;
  trend?: {
    value: string;
    isPositive: boolean;
  };
  variant?: 'default' | 'warning' | 'error' | 'success';
}

export const DashboardCard: React.FC<DashboardCardProps> = ({
  title,
  value,
  subtitle,
  tooltip,
  icon: Icon,
  trend,
  variant = 'default'
}) => {
  const [showTooltip, setShowTooltip] = React.useState(false);

  const variantStyles = {
    default: 'border-slate-200 bg-white',
    warning: 'border-amber-200 bg-amber-50/50',
    error: 'border-red-200 bg-red-50/50',
    success: 'border-emerald-200 bg-emerald-50/50',
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "relative rounded-2xl border p-6 shadow-sm transition-all hover:shadow-md",
        variantStyles[variant]
      )}
    >
      <div className="flex items-start justify-between">
        <div className="rounded-xl bg-slate-100 p-2.5 text-slate-600">
          <Icon size={20} />
        </div>
        <div className="relative">
          <button
            onMouseEnter={() => setShowTooltip(true)}
            onMouseLeave={() => setShowTooltip(false)}
            className="text-slate-400 hover:text-slate-600 transition-colors"
          >
            <Icon name="Info" size={16} className="cursor-help" />
          </button>
          {showTooltip && (
            <div className="absolute right-0 top-6 z-50 w-64 rounded-lg bg-slate-900 p-3 text-xs leading-relaxed text-white shadow-xl">
              {tooltip}
            </div>
          )}
        </div>
      </div>

      <div className="mt-4">
        <h3 className="text-sm font-medium text-slate-500">{title}</h3>
        <div className="mt-1 flex items-baseline gap-2">
          <span className="text-2xl font-bold tracking-tight text-slate-900">{value}</span>
          {trend && (
            <span className={cn(
              "text-xs font-medium",
              trend.isPositive ? "text-emerald-600" : "text-red-600"
            )}>
              {trend.value}
            </span>
          )}
        </div>
        <p className="mt-1 text-xs text-slate-400">{subtitle}</p>
      </div>
    </motion.div>
  );
};
