import React from 'react';
import { 
  BrowserRouter as Router, 
  Routes, 
  Route, 
  Link, 
  useLocation 
} from 'react-router-dom';
import { 
  LayoutDashboard, 
  Stethoscope, 
  Building2, 
  Settings, 
  LogOut,
  Bell,
  Search,
  Menu,
  X,
  Ban,
  Wallet,
  BarChart3
} from 'lucide-react';
import { ProfessionalDashboard } from './pages/ProfessionalDashboard';
import { ManagerDashboard } from './pages/ManagerDashboard';
import { BpoProductionEntry } from './pages/BpoProductionEntry';
import { GlosasManagement } from './pages/GlosasManagement';
import { ManagementPanel } from './pages/ManagementPanel';
import { TransfersManagement } from './pages/TransfersManagement';
import { MasterRegistration } from './pages/MasterRegistration';
import { AuditHistory } from './pages/AuditHistory';
import { Login } from './pages/Login';
import { clsx } from 'clsx';
import { ErrorBoundary } from './components/ErrorBoundary';
import { History, ShieldCheck, Database as DatabaseIcon } from 'lucide-react';

const SidebarItem = ({ to, icon: Icon, label, active, collapsed }: { to: string, icon: any, label: string, active: boolean, collapsed?: boolean }) => (
  <Link
    to={to}
    title={collapsed ? label : ""}
    className={clsx(
      "flex items-center gap-3 rounded-xl py-3 text-sm font-medium transition-all",
      collapsed ? "justify-center px-0" : "px-4",
      active 
        ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200" 
        : "text-slate-500 hover:bg-slate-100 hover:text-slate-900"
    )}
  >
    <Icon size={20} className="min-w-[20px]" />
    {!collapsed && <span>{label}</span>}
  </Link>
);

const App: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(true);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = React.useState(false);
  const [user, setUser] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);
  const [showWelcome, setShowWelcome] = React.useState(false);

  React.useEffect(() => {
    const session = localStorage.getItem('fluxosaude_session');
    if (session) {
      try {
        const data = JSON.parse(session);
        setUser(data.user);
      } catch (e) {
        localStorage.removeItem('fluxosaude_session');
      }
    }
    setLoading(false);
  }, []);

  const handleLogin = (userData: any) => {
    setUser(userData);
    setShowWelcome(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('fluxosaude_session');
    setUser(null);
    setShowWelcome(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="h-12 w-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  if (showWelcome) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="max-w-2xl w-full bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
          <div className="p-8 md:p-12 text-center">
            <div className="h-20 w-20 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-bold text-4xl mx-auto mb-8 shadow-xl shadow-indigo-100">
              F
            </div>
            <h1 className="text-3xl font-bold text-slate-900 mb-6">Bem-vindo à Fluxo Saúde</h1>
            <div className="space-y-6 text-slate-600 leading-relaxed text-lg text-left">
              <p>
                A Fluxo Saúde nasceu para ser a parceira estratégica de profissionais da saúde que querem sair da sobrecarga administrativa e assumir o controle da sua operação.
              </p>
              <p>
                Nossa marca simboliza evolução, organização e resultado, refletindo uma proposta clara: cuidar da gestão para que o profissional possa focar no que faz de mais importante — cuidar de pessoas.
              </p>
            </div>
            <button
              onClick={() => setShowWelcome(false)}
              className="mt-12 w-full md:w-auto px-12 py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all transform hover:scale-[1.02] active:scale-[0.98]"
            >
              Começar agora
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <Router>
        <div className="flex min-h-screen bg-slate-50">
        {/* Sidebar */}
        <aside className={clsx(
          "fixed inset-y-0 left-0 z-50 transform bg-white border-r border-slate-200 transition-all duration-300 ease-in-out lg:relative lg:translate-x-0",
          isSidebarCollapsed ? "w-20" : "w-64",
          !isSidebarOpen && "-translate-x-full"
        )}>
          <div className="flex h-full flex-col p-4">
            <div className={clsx("flex items-center gap-3 mb-10", isSidebarCollapsed ? "justify-center" : "px-2")}>
              <div className="h-8 w-8 min-w-[32px] rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold">F</div>
              {!isSidebarCollapsed && <span className="text-xl font-bold tracking-tight text-slate-900">Fluxo Saúde</span>}
            </div>

            <nav className="flex-1 space-y-2 overflow-y-auto">
              {!isSidebarCollapsed && <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-4 px-4">Menu Principal</div>}
              <SidebarItem to="/" icon={Stethoscope} label={isSidebarCollapsed ? "" : "Painel Médico"} active={window.location.pathname === '/'} collapsed={isSidebarCollapsed} />
              <SidebarItem to="/gestor" icon={Building2} label={isSidebarCollapsed ? "" : "Painel Gestor"} active={window.location.pathname === '/gestor'} collapsed={isSidebarCollapsed} />
              <SidebarItem to="/bpo" icon={LayoutDashboard} label={isSidebarCollapsed ? "" : "Lançamento BPO"} active={window.location.pathname === '/bpo'} collapsed={isSidebarCollapsed} />
              <SidebarItem to="/glosas" icon={Ban} label={isSidebarCollapsed ? "" : "Gestão de Glosas"} active={window.location.pathname === '/glosas'} collapsed={isSidebarCollapsed} />
              <SidebarItem to="/painel-gerencial" icon={BarChart3} label={isSidebarCollapsed ? "" : "Painel Gerencial"} active={window.location.pathname === '/painel-gerencial'} collapsed={isSidebarCollapsed} />
              <SidebarItem to="/repasses" icon={Wallet} label={isSidebarCollapsed ? "" : "Gestão de Repasses"} active={window.location.pathname === '/repasses'} collapsed={isSidebarCollapsed} />
              
              {(user.role === 'ADMIN' || user.role === 'BPO') && (
                <div className="pt-6">
                  {!isSidebarCollapsed && <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-4 px-4">Administração</div>}
                  <SidebarItem to="/cadastros" icon={DatabaseIcon} label={isSidebarCollapsed ? "" : "Cadastros Mestre"} active={window.location.pathname === '/cadastros'} collapsed={isSidebarCollapsed} />
                  <SidebarItem to="/auditoria" icon={History} label={isSidebarCollapsed ? "" : "Histórico Auditoria"} active={window.location.pathname === '/auditoria'} collapsed={isSidebarCollapsed} />
                </div>
              )}

              <div className="pt-6">
                {!isSidebarCollapsed && <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-4 px-4">Configurações</div>}
                <SidebarItem to="/settings" icon={Settings} label={isSidebarCollapsed ? "" : "Ajustes"} active={false} collapsed={isSidebarCollapsed} />
              </div>
            </nav>

            <div className="mt-auto pt-6 border-t border-slate-100">
              <div className={clsx("px-4 py-2 mb-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest", isSidebarCollapsed && "text-center px-0")}>
                {!isSidebarCollapsed ? "Versão 2.1.0 (Audit & RBAC)" : "v2.1"}
              </div>
              <button 
                onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
                className="hidden lg:flex w-full items-center justify-center gap-3 rounded-xl px-4 py-3 text-sm font-medium text-slate-400 hover:bg-slate-50 transition-all mb-2"
              >
                {isSidebarCollapsed ? <Menu size={20} /> : <X size={20} />}
                {!isSidebarCollapsed && "Recolher Menu"}
              </button>
              <button 
                onClick={handleLogout}
                className="flex w-full items-center justify-center gap-3 rounded-xl px-4 py-3 text-sm font-medium text-red-500 hover:bg-red-50 transition-all"
              >
                <LogOut size={20} />
                {!isSidebarCollapsed && "Sair"}
              </button>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
          {/* Top Header */}
          <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 sticky top-0 z-40">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="lg:hidden p-2 text-slate-500"
            >
              <Menu size={24} />
            </button>

            <div className="hidden md:flex items-center bg-slate-100 rounded-full px-4 py-1.5 w-96">
              <Search size={16} className="text-slate-400" />
              <input 
                type="text" 
                placeholder="Buscar paciente ou guia..." 
                className="bg-transparent border-none text-sm focus:ring-0 w-full ml-2"
              />
            </div>

            <div className="flex items-center gap-4">
              <button className="relative p-2 text-slate-400 hover:text-slate-600 transition-colors">
                <Bell size={20} />
                <span className="absolute top-1.5 right-1.5 h-2 w-2 bg-red-500 rounded-full border-2 border-white"></span>
              </button>
              <div className="h-8 w-px bg-slate-200 mx-2"></div>
              <div className="flex items-center gap-3">
                <div className="text-right hidden sm:block">
                  <div className="text-sm font-bold text-slate-900">{user.username === 'admin' ? 'Administrador BPO' : user.username}</div>
                  <div className="text-[10px] text-slate-500 font-medium uppercase tracking-widest">{user.role}</div>
                </div>
                <div className="h-10 w-10 rounded-full bg-slate-200 overflow-hidden border-2 border-white shadow-sm">
                  <img src={`https://picsum.photos/seed/${user.username}/100/100`} alt="Avatar" referrerPolicy="no-referrer" />
                </div>
              </div>
            </div>
          </header>

          {/* Page Content */}
          <div className="flex-1 p-4 md:p-8 overflow-y-auto">
            <div className="max-w-7xl mx-auto">
              <Routes>
                <Route path="/" element={<ProfessionalDashboard />} />
                <Route path="/gestor" element={<ManagerDashboard />} />
                <Route path="/bpo" element={<BpoProductionEntry />} />
                <Route path="/glosas" element={<GlosasManagement />} />
                <Route path="/painel-gerencial" element={<ManagementPanel />} />
                <Route path="/repasses" element={<TransfersManagement />} />
                <Route path="/cadastros" element={<MasterRegistration />} />
                <Route path="/auditoria" element={<AuditHistory />} />
              </Routes>
            </div>
          </div>
        </main>
      </div>
      </Router>
    </ErrorBoundary>
  );
};

export default App;
